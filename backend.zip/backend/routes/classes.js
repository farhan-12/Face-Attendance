const express = require('express');
const router = express.Router();
const classController = require('../controllers/classController');
const { auth, requireRole } = require('../middleware/authMiddleware');

router.post('/', auth, requireRole(['admin']), classController.createClass);
router.get('/', auth, classController.getAll);
router.get('/:id', auth, classController.getById);
router.put('/:id', auth, requireRole(['admin']), classController.update);
router.delete('/:id', auth, requireRole(['admin']), classController.delete);

module.exports = router;
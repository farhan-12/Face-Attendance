const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { auth, requireRole } = require('../middleware/authMiddleware');

router.get('/', auth, requireRole(['admin']), userController.getAll);
router.get('/me', auth, userController.getMe);
router.put('/:id', auth, requireRole(['admin']), userController.update);
router.delete('/:id', auth, requireRole(['admin']), userController.delete);

module.exports = router;
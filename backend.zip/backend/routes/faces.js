const express = require('express');
const router = express.Router();
const faceController = require('../controllers/faceController');
const { auth } = require('../middleware/authMiddleware');

router.post('/register', auth, faceController.registerDescriptors);
router.get('/all', auth, faceController.getAllDescriptors);

module.exports = router;
const express = require('express');
const router = express.Router();
const att = require('../controllers/attendanceController');
const { auth } = require('../middleware/authMiddleware');

router.post('/checkin', auth, att.checkIn);
router.get('/class/:classId', auth, att.getByClass);
router.get('/user/:userId', auth, att.getByUser);

module.exports = router;
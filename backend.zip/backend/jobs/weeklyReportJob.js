const cron = require('node-cron');
const Attendance = require('../models/Attendance');
const Class = require('../models/Class');
const User = require('../models/User');
const { sendMail } = require('../utils/mailer');

/**
 * Run weekly summaries (e.g., every Friday at 17:00)
 * We assume class teacher's email exists.
 */
module.exports = (io) => {
  cron.schedule('0 17 * * FRI', async () => {
    try {
      // Example: for each class, compile last 7 days attendance
      const classes = await Class.find().populate('teacher').populate('students');
      const now = new Date();
      const lastWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

      for (const cls of classes) {
        const recs = await Attendance.find({
          class: cls._id,
          timestamp: { $gte: lastWeek, $lte: now }
        }).populate('user');

        // Build a simple summary
        let html = `<h3>Weekly Attendance Summary for ${cls.title}</h3>`;
        html += `<p>From ${lastWeek.toDateString()} to ${now.toDateString()}</p>`;
        html += '<ul>';
        for (const s of cls.students) {
          const sRecs = recs.filter(r => r.user && r.user._id.toString() === s._id.toString());
          const presentCount = sRecs.length;
          html += `<li>${s.name} (${s.email}): ${presentCount} sessions</li>`;
        }
        html += '</ul>';

        if (cls.teacher && cls.teacher.email) {
          await sendMail({
            to: cls.teacher.email,
            subject: `Weekly attendance summary — ${cls.title}`,
            html
          });
        }
      }
    } catch (err) {
      console.error('Weekly report job failed', err);
    }
  });
};
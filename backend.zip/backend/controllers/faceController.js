/**
 * This controller stores face descriptors (128-d arrays).
 * The frontend (face-api.js) computes descriptors and posts them here.
 */

const User = require('../models/User');

exports.registerDescriptors = async (req, res) => {
  const { userId, descriptors } = req.body;
  // descriptors: array of arrays (float numbers)
  if (!userId || !descriptors) return res.status(400).json({ message: 'Missing data' });
  const user = await User.findById(userId);
  if (!user) return res.status(404).json({ message: 'User not found' });
  // Append descriptors
  descriptors.forEach(d => user.descriptors.push({ descriptor: d }));
  await user.save();
  res.json({ message: 'Descriptors saved' });
};

exports.getAllDescriptors = async (req, res) => {
  // Return user data + descriptors for client-side matching or server-side usage
  const users = await User.find().select('name descriptors role email');
  res.json(users);
};
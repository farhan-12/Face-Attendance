const User = require('../models/User');

exports.getAll = async (req, res) => {
  const users = await User.find().select('-passwordHash');
  res.json(users);
};

exports.getMe = async (req, res) => {
  const user = await User.findById(req.user._id).select('-passwordHash');
  res.json(user);
};

exports.update = async (req, res) => {
  const updates = req.body;
  const user = await User.findByIdAndUpdate(req.params.id, updates, { new: true }).select('-passwordHash');
  res.json(user);
};

exports.delete = async (req, res) => {
  await User.findByIdAndDelete(req.params.id);
  res.json({ message: 'User deleted' });
};
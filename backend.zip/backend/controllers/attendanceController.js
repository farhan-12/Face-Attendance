const Attendance = require('../models/Attendance');
const User = require('../models/User');
const Class = require('../models/Class');

// Record an attendance event. In our pattern, frontend does recognition and sends matched userId.
// For added security, you could also send descriptor and re-check server-side.
exports.checkIn = async (req, res) => {
  const { userId, classId, type } = req.body;
  if (!userId) return res.status(400).json({ message: 'userId required' });
  const user = await User.findById(userId);
  if (!user) return res.status(404).json({ message: 'User not found' });

  // Determine status like 'late' by comparing class schedule (optional)
  const attendance = new Attendance({
    user: userId,
    class: classId || null,
    type: type || 'entry',
    source: 'camera',
  });
  await attendance.save();

  // Optionally emit socket.io event to frontend (server will manage)
  if (req.io && user) {
    req.io.emit('attendance', { user: { id: user._id, name: user.name }, timestamp: attendance.timestamp });
  }

  res.json({ message: 'Attendance recorded', attendance });
};

exports.getByClass = async (req, res) => {
  const { classId } = req.params;
  const records = await Attendance.find({ class: classId }).populate('user').sort({ timestamp: -1 });
  res.json(records);
};

exports.getByUser = async (req, res) => {
  const userId = req.params.userId;
  const records = await Attendance.find({ user: userId }).sort({ timestamp: -1 });
  res.json(records);
};
const Class = require('../models/Class');

exports.createClass = async (req, res) => {
  const cls = new Class(req.body);
  await cls.save();
  res.json(cls);
};

exports.getAll = async (req, res) => {
  const list = await Class.find().populate('teacher').populate('students');
  res.json(list);
};

exports.getById = async (req, res) => {
  const cls = await Class.findById(req.params.id).populate('teacher').populate('students');
  res.json(cls);
};

exports.update = async (req, res) => {
  const cls = await Class.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(cls);
};

exports.delete = async (req, res) => {
  await Class.findByIdAndDelete(req.params.id);
  res.json({ message: 'Class deleted' });
};
const mongoose = require('mongoose');

const AttendanceSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  class: { type: mongoose.Schema.Types.ObjectId, ref: 'Class' },
  timestamp: { type: Date, default: Date.now },
  type: { type: String, enum: ['entry','exit'], default: 'entry' },
  status: { type: String, enum: ['present','late','absent'], default: 'present' },
  source: { type: String } // e.g., 'camera'
});

module.exports = mongoose.model('Attendance', AttendanceSchema);
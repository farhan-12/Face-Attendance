const mongoose = require('mongoose');

const ClassSchema = new mongoose.Schema({
  title: { type: String, required: true },
  code: { type: String, required: true, unique: true },
  teacher: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  students: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  schedule: [{
    dayOfWeek: { type: String }, // e.g., "Monday"
    startTime: { type: String }, // "09:00"
    endTime: { type: String }    // "10:00"
  }]
});

module.exports = mongoose.model('Class', ClassSchema);
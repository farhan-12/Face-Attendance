const mongoose = require('mongoose');

const FaceDescriptorSchema = new mongoose.Schema({
  descriptor: { type: [Number], required: true }, // 128-d vector
  createdAt: { type: Date, default: Date.now }
});

const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  passwordHash: { type: String, required: true },
  role: { type: String, enum: ['student','teacher','admin'], default: 'student' },
  descriptors: [FaceDescriptorSchema],
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('User', UserSchema);
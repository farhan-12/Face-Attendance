require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const connectDB = require('./config/db');
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const classRoutes = require('./routes/classes');
const faceRoutes = require('./routes/faces');
const attendanceRoutes = require('./routes/attendance');
const weeklyJob = require('./jobs/weeklyReportJob');

const app = express();
const server = http.createServer(app);
const { Server } = require('socket.io');
const { start } = require('repl');
const io = new Server(server, {
  cors: { origin: '*' }
});

// Attach io to req in middleware so controllers can emit
app.use((req, res, next) => { req.io = io; next(); });

app.use(cors());
app.use(express.json({ limit: '10mb' })); // large payload allowed for descriptor arrays

connectDB();
app.get('/', (req, res) => {
  res.send('API is running...');
});
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/classes', classRoutes);
app.use('/api/faces', faceRoutes);
app.use('/api/attendance', attendanceRoutes);
// socket.io basic
io.on('connection', (socket) => {
  console.log('Socket connected', socket.id);
  socket.on('disconnect', () => console.log('Socket disconnected', socket.id));
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  // start the weekly job with access to io
  weeklyJob(io);
});
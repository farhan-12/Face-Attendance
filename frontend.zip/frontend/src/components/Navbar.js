import React from 'react';

export default function Navbar(){
  const logout = () => {
    localStorage.removeItem('token');
    window.location = '/login';
  };
  return (
    <nav style={{ padding: 10, borderBottom: '1px solid #ddd' }}>
      <a href="/admin">Admin</a> | <a href="/teacher">Teacher</a> | <a href="/student">Student</a> | <a href="/enroll">Enroll</a> | <a href="/live">Live</a>
      <button style={{ float: 'right' }} onClick={logout}>Logout</button>
    </nav>
  );
}
import React, { useEffect, useState } from 'react';
import API from '../api/api';

export default function AdminDashboard() {
  const [users, setUsers] = useState([]);
  useEffect(() => {
    const load = async () => {
      try {
        const res = await API.get('/users');
        setUsers(res.data);
      } catch (err) {
        console.error(err);
      }
    }
    load();
  }, []);
  return (
    <div style={{ padding: 20 }}>
      <h2>Admin Dashboard</h2>
      <p><a href="/enroll">Enroll Face</a> | <a href="/live">Live Scan</a></p>
      <h3>All Users</h3>
      <ul>
        {users.map(u => <li key={u._id}>{u.name} - {u.email} - {u.role}</li>)}
      </ul>
    </div>
  );
}
import React, { useEffect, useRef, useState } from 'react';
import Webcam from 'react-webcam';
import * as faceapi from 'face-api.js';
import API from '../api/api';
import io from 'socket.io-client';

const MODEL_URL = '/models';
const socket = io(process.env.REACT_APP_SOCKET_URL || 'http://localhost:5000');

function euclideanDistance(a, b) {
  let sum = 0;
  for (let i=0;i<a.length;i++) {
    const diff = a[i] - b[i];
    sum += diff * diff;
  }
  return Math.sqrt(sum);
}

export default function LiveScan(){
  const webcamRef = useRef(null);
  const [loaded, setLoaded] = useState(false);
  const [labeledDescriptors, setLabeledDescriptors] = useState([]); // { userId, name, descriptors: [arrays] }
  const [log, setLog] = useState([]);
  const threshold = 0.6; // typical threshold for face-api embeddings

  useEffect(() => {
    (async () => {
      await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
      await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL);
      await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL);
      setLoaded(true);
      // fetch descriptors
      const res = await API.get('/faces/all');
      // server returns users with descriptors
      const data = res.data.map(u => ({
        userId: u._id,
        name: u.name,
        descriptors: u.descriptors.map(d => d.descriptor)
      }));
      setLabeledDescriptors(data);
    })();
  }, []);

  useEffect(() => {
    socket.on('attendance', (payload) => {
      setLog(l => [`${new Date(payload.timestamp).toLocaleTimeString()} - ${payload.user.name} checked in`, ...l]);
    });
    return () => socket.disconnect();
  }, []);

  const scanOnce = async () => {
    if (!webcamRef.current) return;
    const video = webcamRef.current.video;
    const detection = await faceapi.detectSingleFace(video, new faceapi.TinyFaceDetectorOptions()).withFaceLandmarks().withFaceDescriptor();
    if (!detection) {
      setLog(l=>[`No face detected (${new Date().toLocaleTimeString()})`, ...l]);
      return;
    }
    const descriptor = Array.from(detection.descriptor);
    // find best match
    let best = { user: null, dist: Infinity };
    for (const user of labeledDescriptors) {
      for (const d of user.descriptors) {
        const dist = euclideanDistance(descriptor, d);
        if (dist < best.dist) best = { user, dist };
      }
    }
    if (best.user && best.dist < threshold) {
      // recognized
      setLog(l=>[`${best.user.name} recognized (d=${best.dist.toFixed(3)}) at ${new Date().toLocaleTimeString()}`, ...l]);
      // send to server to record
      try {
        await API.post('/attendance/checkin', { userId: best.user.userId, source: 'camera' });
      } catch (err) {
        console.error(err);
      }
    } else {
      setLog(l=>[`Unknown face detected at ${new Date().toLocaleTimeString()}`, ...l]);
      // optionally hit endpoint for unknown face alarm
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Live Scanner</h2>
      {loaded ? (
        <>
          <Webcam audio={false} ref={webcamRef} videoConstraints={{ width: 640, height: 480 }} />
          <div style={{ marginTop: 10 }}>
            <button onClick={scanOnce}>Scan Now</button>
            <button onClick={() => setLog([])}>Clear Log</button>
          </div>
          <div style={{ marginTop: 10 }}>
            <h4>Log</h4>
            <ul>
              {log.map((l, i) => <li key={i}>{l}</li>)}
            </ul>
          </div>
        </>
      ) : <div>Loading models...</div>}
    </div>
  );
}
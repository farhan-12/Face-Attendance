import React from 'react';

export default function TeacherDashboard(){
  return (
    <div style={{ padding: 20 }}>
      <h2>Teacher Dashboard</h2>
      <p><a href="/live">Open Live Scanner</a></p>
      <p>View class rosters and weekly summaries will be emailed automatically.</p>
    </div>
  );
}
import React, { useRef, useEffect, useState } from 'react';
import Webcam from 'react-webcam';
import * as faceapi from 'face-api.js';
import API from '../api/api';

const MODEL_URL = '/models';

export default function FaceEnroll(){
  const webcamRef = useRef(null);
  const [loaded, setLoaded] = useState(false);
  const [userId, setUserId] = useState('');
  const [capturedDescriptors, setCapturedDescriptors] = useState([]);

  useEffect(() => {
    (async () => {
      await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
      await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL);
      await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL);
      setLoaded(true);
    })();
  }, []);

  const capture = async () => {
    if (!webcamRef.current) return;
    const video = webcamRef.current.video;
    const canvas = await faceapi.createCanvasFromMedia(video);
    const detection = await faceapi.detectSingleFace(video, new faceapi.TinyFaceDetectorOptions()).withFaceLandmarks().withFaceDescriptor();
    if (!detection) {
      alert('No face detected. Try again.');
      return;
    }
    const descriptor = Array.from(detection.descriptor); // convert Float32Array to normal array
    setCapturedDescriptors(prev => [...prev, descriptor]);
    alert('Captured descriptor #' + (capturedDescriptors.length + 1));
  };

  const save = async () => {
    if (!userId) return alert('Provide userId (DB id) to save descriptors');
    if (capturedDescriptors.length === 0) return alert('Capture at least one sample');
    await API.post('/faces/register', { userId, descriptors: capturedDescriptors });
    alert('Descriptors saved to user');
    setCapturedDescriptors([]);
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Face Enrollment</h2>
      <div>
        <label>Target user DB id: </label>
        <input value={userId} onChange={e=>setUserId(e.target.value)} placeholder="Enter user id" />
      </div>
      <div style={{ marginTop: 10 }}>
        {loaded ? (
          <>
            <Webcam audio={false} ref={webcamRef} videoConstraints={{ width: 640, height: 480 }} />
            <div>
              <button onClick={capture}>Capture Face</button>
              <button onClick={save}>Save to DB</button>
            </div>
            <div>Captured: {capturedDescriptors.length}</div>
          </>
        ) : <div>Loading models...</div>}
      </div>
    </div>
  );
}
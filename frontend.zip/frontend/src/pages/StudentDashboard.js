import React, { useEffect, useState } from 'react';
import API from '../api/api';

export default function StudentDashboard() {
  const [me, setMe] = useState(null);
  const [records, setRecords] = useState([]);
  useEffect(() => {
    const load = async () => {
      try {
        const res = await API.get('/users/me');
        setMe(res.data);
        const rec = await API.get(`/attendance/user/${res.data._id}`);
        setRecords(rec.data);
      } catch (err) { console.error(err); }
    };
    load();
  }, []);
  return (
    <div style={{ padding: 20 }}>
      <h2>Student Dashboard</h2>
      {me && <p>Welcome {me.name}</p>}
      <h3>Your attendance</h3>
      <ul>{records.map(r => <li key={r._id}>{new Date(r.timestamp).toLocaleString()} - {r.status}</li>)}</ul>
      <p><a href="/live">Open Live Scanner (for check-in)</a></p>
    </div>
  );
}
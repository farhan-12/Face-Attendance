import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import AdminDashboard from './pages/AdminDashboard';
import TeacherDashboard from './pages/TeacherDashboard';
import StudentDashboard from './pages/StudentDashboard';
import FaceEnroll from './pages/FaceEnroll';
import LiveScan from './pages/LiveScan';
import { setToken } from './api/api';

function App() {
  useEffect(() => {
    const token = localStorage.getItem('token');
    setToken(token);
  }, []);

  const PrivateRoute = ({ children }) => {
    const token = localStorage.getItem('token');
    return token ? children : <Navigate to="/login" />;
  };

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/admin" element={<PrivateRoute><AdminDashboard/></PrivateRoute>} />
        <Route path="/teacher" element={<PrivateRoute><TeacherDashboard/></PrivateRoute>} />
        <Route path="/student" element={<PrivateRoute><StudentDashboard/></PrivateRoute>} />
        <Route path="/enroll" element={<PrivateRoute><FaceEnroll/></PrivateRoute>} />
        <Route path="/live" element={<PrivateRoute><LiveScan/></PrivateRoute>} />
        <Route path="*" element={<Navigate to="/login" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;